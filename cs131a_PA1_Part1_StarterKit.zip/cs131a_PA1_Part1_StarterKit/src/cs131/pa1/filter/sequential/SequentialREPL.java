package cs131.pa1.filter.sequential;

public class SequentialREPL {

	static String currentWorkingDirectory;
	
	public static void main(String[] args){
		
	}

}
